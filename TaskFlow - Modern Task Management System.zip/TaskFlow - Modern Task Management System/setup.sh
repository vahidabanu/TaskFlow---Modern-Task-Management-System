#!/bin/bash

# TaskFlow Setup Script
# This script sets up the complete development environment for TaskFlow

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Function to check if command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Function to check prerequisites
check_prerequisites() {
    print_status "Checking prerequisites..."
    
    local missing_deps=()
    
    if ! command_exists node; then
        missing_deps+=("Node.js")
    fi
    
    if ! command_exists npm; then
        missing_deps+=("npm")
    fi
    
    if ! command_exists java; then
        missing_deps+=("Java 17")
    fi
    
    if ! command_exists docker; then
        missing_deps+=("Docker")
    fi
    
    if ! command_exists docker-compose; then
        missing_deps+=("Docker Compose")
    fi
    
    if [ ${#missing_deps[@]} -ne 0 ]; then
        print_error "Missing dependencies: ${missing_deps[*]}"
        print_status "Please install the missing dependencies and run this script again."
        exit 1
    fi
    
    print_success "All prerequisites are installed!"
}

# Function to setup frontend
setup_frontend() {
    print_status "Setting up frontend..."
    
    cd frontend
    
    # Install dependencies
    print_status "Installing frontend dependencies..."
    npm install
    
    # Create .env.local file
    if [ ! -f .env.local ]; then
        print_status "Creating .env.local file..."
        cat > .env.local << EOF
NEXT_PUBLIC_API_URL=http://localhost:8080
NODE_ENV=development
EOF
        print_success "Created .env.local file"
    fi
    
    cd ..
    print_success "Frontend setup completed!"
}

# Function to setup backend
setup_backend() {
    print_status "Setting up backend..."
    
    cd backend
    
    # Check if Maven wrapper exists, if not create it
    if [ ! -f mvnw ]; then
        print_status "Creating Maven wrapper..."
        mvn wrapper:wrapper
    fi
    
    # Make mvnw executable
    chmod +x mvnw
    
    # Install dependencies
    print_status "Installing backend dependencies..."
    ./mvnw clean install -DskipTests
    
    # Create application-dev.yml if it doesn't exist
    if [ ! -f src/main/resources/application-dev.yml ]; then
        print_status "Creating application-dev.yml..."
        cat > src/main/resources/application-dev.yml << EOF
spring:
  data:
    mongodb:
      uri: mongodb://localhost:27017/taskflow-dev

logging:
  level:
    com.taskflow: DEBUG
    org.springframework.security: DEBUG
EOF
        print_success "Created application-dev.yml file"
    fi
    
    cd ..
    print_success "Backend setup completed!"
}

# Function to setup database
setup_database() {
    print_status "Setting up database..."
    
    # Check if MongoDB is running
    if ! docker ps | grep -q mongodb; then
        print_status "Starting MongoDB with Docker..."
        docker run -d \
            --name taskflow-mongodb \
            -p 27017:27017 \
            -e MONGO_INITDB_ROOT_USERNAME=admin \
            -e MONGO_INITDB_ROOT_PASSWORD=password123 \
            -e MONGO_INITDB_DATABASE=taskflow \
            mongo:7.0
        
        print_success "MongoDB started successfully!"
    else
        print_warning "MongoDB is already running"
    fi
}

# Function to create development environment file
create_env_file() {
    print_status "Creating development environment file..."
    
    if [ ! -f .env ]; then
        cat > .env << EOF
# Development Environment Variables
SPRING_PROFILES_ACTIVE=dev
MONGODB_URI=mongodb://admin:password123@localhost:27017/taskflow?authSource=admin
JWT_SECRET=dev-jwt-secret-key-for-development-only
JWT_EXPIRATION=86400000
JWT_REFRESH_EXPIRATION=604800000
CORS_ALLOWED_ORIGINS=http://localhost:3000
NEXT_PUBLIC_API_URL=http://localhost:8080
EOF
        print_success "Created .env file"
    else
        print_warning ".env file already exists"
    fi
}

# Function to start development servers
start_development() {
    print_status "Starting development servers..."
    
    # Start backend
    print_status "Starting Spring Boot backend..."
    cd backend
    ./mvnw spring-boot:run &
    BACKEND_PID=$!
    cd ..
    
    # Wait for backend to start
    print_status "Waiting for backend to start..."
    sleep 10
    
    # Start frontend
    print_status "Starting Next.js frontend..."
    cd frontend
    npm run dev &
    FRONTEND_PID=$!
    cd ..
    
    print_success "Development servers started!"
    print_status "Backend PID: $BACKEND_PID"
    print_status "Frontend PID: $FRONTEND_PID"
    print_status ""
    print_success "🎉 TaskFlow is now running!"
    print_status "Frontend: http://localhost:3000"
    print_status "Backend: http://localhost:8080"
    print_status "API Docs: http://localhost:8080/swagger-ui.html"
    print_status "MongoDB: mongodb://localhost:27017"
    print_status ""
    print_warning "To stop the servers, run: kill $BACKEND_PID $FRONTEND_PID"
}

# Function to run tests
run_tests() {
    print_status "Running tests..."
    
    # Backend tests
    print_status "Running backend tests..."
    cd backend
    ./mvnw test
    cd ..
    
    # Frontend tests
    print_status "Running frontend tests..."
    cd frontend
    npm test
    cd ..
    
    print_success "All tests completed!"
}

# Function to show help
show_help() {
    echo "TaskFlow Setup Script"
    echo ""
    echo "Usage: $0 [OPTION]"
    echo ""
    echo "Options:"
    echo "  setup       Complete setup (default)"
    echo "  frontend    Setup frontend only"
    echo "  backend     Setup backend only"
    echo "  database    Setup database only"
    echo "  start       Start development servers"
    echo "  test        Run all tests"
    echo "  help        Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 setup    # Complete setup"
    echo "  $0 start    # Start development servers"
    echo "  $0 test     # Run tests"
}

# Main script
main() {
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║                    TaskFlow Setup Script                    ║"
    echo "║                                                              ║"
    echo "║  🚀 Setting up your development environment...              ║"
    echo "║  📚 Frontend: Next.js + TypeScript + Tailwind CSS          ║"
    echo "║  ☕ Backend: Spring Boot + Java 17 + MongoDB                ║"
    echo "║  🐳 Database: MongoDB with Docker                          ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo ""
    
    case "${1:-setup}" in
        "setup")
            check_prerequisites
            setup_database
            create_env_file
            setup_backend
            setup_frontend
            print_success "🎉 TaskFlow setup completed successfully!"
            print_status "Run '$0 start' to start the development servers"
            ;;
        "frontend")
            setup_frontend
            ;;
        "backend")
            setup_backend
            ;;
        "database")
            setup_database
            ;;
        "start")
            start_development
            ;;
        "test")
            run_tests
            ;;
        "help"|"-h"|"--help")
            show_help
            ;;
        *)
            print_error "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
}

# Run main function with all arguments
main "$@"
