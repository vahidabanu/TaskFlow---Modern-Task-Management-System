package com.taskflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.config.EnableMongoAuditing;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Main Spring Boot application class for TaskFlow Backend
 * 
 * This application provides a RESTful API for task management with the following features:
 * - User authentication and authorization using JWT
 * - CRUD operations for tasks
 * - Task categorization and prioritization
 * - Real-time notifications
 * - Email notifications
 * - API documentation with Swagger/OpenAPI
 * 
 * @author TaskFlow Team
 * @version 1.0.0
 */
@SpringBootApplication
@EnableMongoAuditing
@EnableAsync
@EnableScheduling
public class TaskFlowApplication {

    public static void main(String[] args) {
        SpringApplication.run(TaskFlowApplication.class, args);
        
        System.out.println("""
            ╔══════════════════════════════════════════════════════════════╗
            ║                    TaskFlow Backend Started                  ║
            ║                                                              ║
            ║  🚀 Application is running on: http://localhost:8080        ║
            ║  📚 API Documentation: http://localhost:8080/swagger-ui.html ║
            ║  🗄️  MongoDB: Connected                                     ║
            ║  🔐 JWT Authentication: Enabled                             ║
            ║  📧 Email Service: Configured                               ║
            ║                                                              ║
            ║  Built with:                                                ║
            ║  • Spring Boot 3.2.0                                        ║
            ║  • Java 17                                                  ║
            ║  • MongoDB                                                  ║
            ║  • Spring Security                                          ║
            ║  • JWT                                                      ║
            ║                                                              ║
            ╚══════════════════════════════════════════════════════════════╝
            """);
    }
}
