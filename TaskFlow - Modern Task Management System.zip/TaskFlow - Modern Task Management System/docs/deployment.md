# Deployment Guide - TaskFlow

This guide provides step-by-step instructions for deploying the TaskFlow application to production environments.

## 🚀 Quick Deploy Links

- **Frontend (Vercel)**: [https://taskflow-nextjs.vercel.app](https://taskflow-nextjs.vercel.app)
- **Backend (AWS)**: [https://taskflow-api.aws.com](https://taskflow-api.aws.com)
- **API Documentation**: [https://taskflow-api.aws.com/swagger-ui.html](https://taskflow-api.aws.com/swagger-ui.html)

## 📋 Prerequisites

- GitHub account
- Vercel account (free tier available)
- AWS account
- MongoDB Atlas account (free tier available)
- Domain name (optional)

## 🎯 Frontend Deployment (Vercel)

### Step 1: Prepare the Repository

1. Push your code to GitHub:
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/your-username/taskflow.git
git push -u origin main
```

### Step 2: Deploy to Vercel

1. Go to [Vercel Dashboard](https://vercel.com/dashboard)
2. Click "New Project"
3. Import your GitHub repository
4. Configure the project:
   - **Framework Preset**: Next.js
   - **Root Directory**: `frontend`
   - **Build Command**: `npm run build`
   - **Output Directory**: `.next`
   - **Install Command**: `npm install`

### Step 3: Environment Variables

Add these environment variables in Vercel:

```env
NEXT_PUBLIC_API_URL=https://taskflow-api.aws.com
NODE_ENV=production
```

### Step 4: Deploy

1. Click "Deploy"
2. Wait for the build to complete
3. Your app will be available at: `https://your-project.vercel.app`

### Step 5: Custom Domain (Optional)

1. Go to your project settings in Vercel
2. Navigate to "Domains"
3. Add your custom domain
4. Configure DNS records as instructed

## ☁️ Backend Deployment (AWS)

### Option 1: AWS EC2 with Docker

#### Step 1: Launch EC2 Instance

1. Go to AWS Console → EC2
2. Click "Launch Instance"
3. Choose Amazon Linux 2023
4. Select t3.medium (recommended for production)
5. Configure Security Group:
   - SSH (22): Your IP
   - HTTP (80): 0.0.0.0/0
   - HTTPS (443): 0.0.0.0/0
   - Custom TCP (8080): 0.0.0.0/0

#### Step 2: Connect and Setup

```bash
# Connect to your instance
ssh -i your-key.pem ec2-user@your-instance-ip

# Update system
sudo yum update -y

# Install Docker
sudo yum install -y docker
sudo systemctl start docker
sudo systemctl enable docker
sudo usermod -a -G docker ec2-user

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Logout and login again
exit
ssh -i your-key.pem ec2-user@your-instance-ip
```

#### Step 3: Deploy Application

```bash
# Clone your repository
git clone https://github.com/your-username/taskflow.git
cd taskflow

# Create production environment file
cat > .env << EOF
SPRING_PROFILES_ACTIVE=prod
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/taskflow
JWT_SECRET=your-super-secret-jwt-key-that-should-be-at-least-256-bits-long
JWT_EXPIRATION=86400000
JWT_REFRESH_EXPIRATION=604800000
CORS_ALLOWED_ORIGINS=https://taskflow-nextjs.vercel.app
EOF

# Deploy with Docker Compose
docker-compose -f docker-compose.prod.yml up -d
```

### Option 2: AWS ECS (Recommended for Production)

#### Step 1: Create ECR Repository

```bash
aws ecr create-repository --repository-name taskflow-backend
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin your-account-id.dkr.ecr.us-east-1.amazonaws.com
```

#### Step 2: Build and Push Docker Image

```bash
cd backend
docker build -t taskflow-backend .
docker tag taskflow-backend:latest your-account-id.dkr.ecr.us-east-1.amazonaws.com/taskflow-backend:latest
docker push your-account-id.dkr.ecr.us-east-1.amazonaws.com/taskflow-backend:latest
```

#### Step 3: Create ECS Cluster and Service

1. Go to AWS Console → ECS
2. Create a new cluster
3. Create a task definition with your Docker image
4. Create a service with Application Load Balancer
5. Configure environment variables and secrets

### Option 3: AWS Elastic Beanstalk

1. Go to AWS Console → Elastic Beanstalk
2. Create a new application
3. Choose "Docker" platform
4. Upload your application code
5. Configure environment variables
6. Deploy

## 🗄️ Database Setup (MongoDB Atlas)

### Step 1: Create Cluster

1. Go to [MongoDB Atlas](https://cloud.mongodb.com)
2. Create a free cluster
3. Choose your preferred cloud provider and region

### Step 2: Configure Network Access

1. Go to "Network Access"
2. Add your IP address or `0.0.0.0/0` for all IPs
3. Create a database user with read/write permissions

### Step 3: Get Connection String

1. Go to "Database Access"
2. Click "Connect"
3. Choose "Connect your application"
4. Copy the connection string
5. Replace `<password>` with your actual password

## 🔧 Environment Variables

### Frontend (Vercel)
```env
NEXT_PUBLIC_API_URL=https://taskflow-api.aws.com
NODE_ENV=production
```

### Backend (AWS)
```env
SPRING_PROFILES_ACTIVE=prod
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/taskflow
JWT_SECRET=your-super-secret-jwt-key-that-should-be-at-least-256-bits-long
JWT_EXPIRATION=86400000
JWT_REFRESH_EXPIRATION=604800000
CORS_ALLOWED_ORIGINS=https://taskflow-nextjs.vercel.app
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
```

## 🔒 Security Considerations

### SSL/TLS Certificate
- Use AWS Certificate Manager for HTTPS
- Configure Application Load Balancer with SSL termination
- Redirect HTTP to HTTPS

### Environment Variables
- Never commit secrets to version control
- Use AWS Secrets Manager for sensitive data
- Rotate JWT secrets regularly

### Database Security
- Use MongoDB Atlas network access controls
- Enable database encryption at rest
- Use strong passwords and enable MFA

## 📊 Monitoring and Logging

### AWS CloudWatch
- Set up CloudWatch logs for application monitoring
- Create alarms for error rates and response times
- Monitor resource utilization

### Application Monitoring
- Implement health check endpoints
- Add structured logging
- Monitor API response times

## 🔄 CI/CD Pipeline

### GitHub Actions Example

```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  deploy-frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Deploy to Vercel
        uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}

  deploy-backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Deploy to AWS
        run: |
          # Your deployment script
```

## 🚨 Troubleshooting

### Common Issues

1. **CORS Errors**: Ensure CORS_ALLOWED_ORIGINS includes your frontend URL
2. **Database Connection**: Verify MongoDB connection string and network access
3. **JWT Issues**: Check JWT_SECRET and expiration settings
4. **Build Failures**: Check Node.js and Java versions

### Health Checks

- Frontend: `https://your-domain.vercel.app/api/health`
- Backend: `https://your-api-domain/api/health`

## 📈 Performance Optimization

### Frontend
- Enable Next.js image optimization
- Use CDN for static assets
- Implement proper caching strategies

### Backend
- Configure JVM heap size appropriately
- Use connection pooling for database
- Implement caching with Redis (optional)

## 🎉 Success!

After following these steps, your TaskFlow application will be live at:
- **Frontend**: https://taskflow-nextjs.vercel.app
- **Backend**: https://taskflow-api.aws.com
- **API Docs**: https://taskflow-api.aws.com/swagger-ui.html

## 📞 Support

If you encounter any issues during deployment:
1. Check the logs in your deployment platform
2. Verify all environment variables are set correctly
3. Ensure network connectivity between services
4. Review security group and firewall settings
