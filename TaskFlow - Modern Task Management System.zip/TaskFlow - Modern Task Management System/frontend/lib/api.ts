import axios, { AxiosInstance, AxiosResponse } from 'axios';
import { ApiResponse, AuthResponse, Task, CreateTaskForm, UpdateTaskForm, TaskFilters, TaskStats } from '@/types';

// API base URL
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8080';

// Create axios instance
const apiClient: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response: AxiosResponse) => {
    return response;
  },
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// Auth API
export const authAPI = {
  login: async (email: string, password: string): Promise<AuthResponse> => {
    const response = await apiClient.post<ApiResponse<AuthResponse>>('/api/auth/login', {
      email,
      password,
    });
    return response.data.data!;
  },

  register: async (name: string, email: string, password: string): Promise<AuthResponse> => {
    const response = await apiClient.post<ApiResponse<AuthResponse>>('/api/auth/register', {
      name,
      email,
      password,
    });
    return response.data.data!;
  },

  logout: async (): Promise<void> => {
    await apiClient.post('/api/auth/logout');
  },

  refreshToken: async (refreshToken: string): Promise<AuthResponse> => {
    const response = await apiClient.post<ApiResponse<AuthResponse>>('/api/auth/refresh', {
      refreshToken,
    });
    return response.data.data!;
  },

  getProfile: async () => {
    const response = await apiClient.get<ApiResponse<any>>('/api/auth/profile');
    return response.data.data;
  },
};

// Tasks API
export const tasksAPI = {
  getAll: async (filters?: TaskFilters): Promise<Task[]> => {
    const params = new URLSearchParams();
    if (filters) {
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });
    }
    
    const response = await apiClient.get<ApiResponse<Task[]>>(`/api/tasks?${params.toString()}`);
    return response.data.data!;
  },

  getById: async (id: string): Promise<Task> => {
    const response = await apiClient.get<ApiResponse<Task>>(`/api/tasks/${id}`);
    return response.data.data!;
  },

  create: async (task: CreateTaskForm): Promise<Task> => {
    const response = await apiClient.post<ApiResponse<Task>>('/api/tasks', task);
    return response.data.data!;
  },

  update: async (id: string, task: UpdateTaskForm): Promise<Task> => {
    const response = await apiClient.put<ApiResponse<Task>>(`/api/tasks/${id}`, task);
    return response.data.data!;
  },

  delete: async (id: string): Promise<void> => {
    await apiClient.delete(`/api/tasks/${id}`);
  },

  updateStatus: async (id: string, status: string): Promise<Task> => {
    const response = await apiClient.patch<ApiResponse<Task>>(`/api/tasks/${id}/status`, { status });
    return response.data.data!;
  },

  getStats: async (): Promise<TaskStats> => {
    const response = await apiClient.get<ApiResponse<TaskStats>>('/api/tasks/stats');
    return response.data.data!;
  },
};

// Categories API
export const categoriesAPI = {
  getAll: async () => {
    const response = await apiClient.get<ApiResponse<any[]>>('/api/categories');
    return response.data.data;
  },
};

// Priorities API
export const prioritiesAPI = {
  getAll: async () => {
    const response = await apiClient.get<ApiResponse<any[]>>('/api/priorities');
    return response.data.data;
  },
};

// Error handling utility
export const handleApiError = (error: any): string => {
  if (error.response?.data?.message) {
    return error.response.data.message;
  }
  
  if (error.response?.data?.error) {
    return error.response.data.error;
  }
  
  if (error.message) {
    return error.message;
  }
  
  return 'An unexpected error occurred';
};

// API response wrapper
export const apiWrapper = async <T>(
  apiCall: () => Promise<T>
): Promise<{ data: T | null; error: string | null }> => {
  try {
    const data = await apiCall();
    return { data, error: null };
  } catch (error: any) {
    const errorMessage = handleApiError(error);
    return { data: null, error: errorMessage };
  }
};

export default apiClient;
